<?php
namespace Modules\Ecommerce\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use App\Models\Country;
use App\Models\Super\ShippingMethods;
use DateTime;
use Exception;
use Modules\Ecommerce\Models\Order;
use Modules\Ecommerce\Models\OrderShipments;
use Modules\Ecommerce\Models\OrderStatus;
use Modules\Ecommerce\Models\OrderUpdates;
use Modules\Ecommerce\Models\ProductsOptionsValues;
use Modules\WebsiteSetting\Models\TempImages;

class OrderController extends Controller
{
    public $page = 'orders';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request){
   
       //Validate user page access
        $api_token = $request->api_token;
         if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
             return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');


        $current_page = !empty($request->page)?$request->page:1;
        $perPage = !empty($request->perPage)?(int)$request->perPage: ApiHelper::perPageItem();
        $search = $request->search;
        $sortBy = $request->sortBy;
        $orderBy = $request->orderBy;
        
        /*Fetching subscriber data*/ 
        $orders_query = Order::with('user','address');
        //  $orders_query = ApiHelper::attach_query_permission_filter($orders_query, $api_token, $this->page, $this->pageview);

        $dateFormat= ApiHelper::dateFormat();

        /*Checking if search data is not empty*/
        if ($request->has('search')) {
            if($request->search !=NULL){
                $orders_query = $orders_query
                ->orWhere("order_number","LIKE", "%{$search}%")
                ->orWhereHas('address',function ($orderQuery)use($search)
                {
                    $orderQuery->where("customer_name","LIKE", "%{$search}%")
                    ->orWhere('customer_email','Like','%'.$search.'%');
                });
            }
        }
        
        if(empty($request->search)){
         /* Add Start Date Filter  */
            if ($request->has('start_date')) {
                if($request->start_date !=NULL){
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                    $start_date = $myDateTime->format('Y-m-d');
                    
                    $orders_query = $orders_query->whereDate('created_at', '>=', $start_date);
            }
            }

            /* Add End Date Filter  */
            if ($request->has('end_date')) {
                if($request->end_date !=NULL){
                    $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                    $end_date = $myDateTime->format('Y-m-d');
                    
                    $orders_query = $orders_query->whereDate('created_at', '<=', $end_date);
                }
            }
        }

        /* order by sorting */
        if(!empty($sortBy) && !empty($orderBy))
            $orders_query = $orders_query->orderBy($sortBy,$orderBy);
        else
            $orders_query = $orders_query->orderBy('order_id','DESC');

        $skip = ($current_page == 1)?0:(int)($current_page-1)*$perPage;

        $orders_count = $orders_query->count();

        $orders_list = $orders_query->skip($skip)->take($perPage)->get();
        
        $order_status=OrderStatus::where('status',1)->orderBy('sort_order', 'ASC')->get();


        /*Binding data into a variable*/
        $res = [
            'order_list'=>$orders_list,
            'current_page'=>$current_page,
            'total_records'=>$orders_count,
            'total_page'=>ceil((int)$orders_count/(int)$perPage),
            'per_page'=>$perPage,
            'date_format'=>$dateFormat,
            'search'=>$search ?? '',
            'order_status'=>$order_status,
            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
        ];
        return ApiHelper::JSON_RESPONSE(true,$res,'');   
    }


    public function orderDetails(Request $request)
    {   
       $api_token = $request->api_token;

       $order_details=Order::with('item','address','user','item.product.productdescription')->where('order_number',$request->order_number)->first();

       if(!empty($order_details))
       {   
           foreach($order_details->item as $key=>$itemValue)
           {
               $attrOptArray= [];
               $p_id = $itemValue->product_id;
               if(!empty($itemValue->attributes))
               {
                   $attrArray=explode(',',$itemValue->attributes);
                   foreach($attrArray as $attrVal)
                   {    
                       $options_values_id=explode('_',$attrVal)[1];
                       $optAttr=ProductsOptionsValues::with('product_options')->where('products_options_values_id',$options_values_id)->first();
                       $attrOptArray[$optAttr->product_options->products_options_name ?? '']=$optAttr->products_options_values_name ?? '';
                    }
               }
               $itemValue->attributes = $attrOptArray;
           }


           foreach($order_details->address as $address_data )
           {  
                if($address_data->address_type==1)
                {   
                    $address_data->country_name=Country::where('countries_id',$address_data->countries_id)->first()->countries_name;
                    $order_details->billing= $address_data;

                }
                else
                {   
                    $address_data->country_name=Country::where('countries_id',$address_data->countries_id)->first()->countries_name;
                    $order_details->shipping= $address_data;
                }
           }

       }

       $order_status=OrderStatus::where('status',1)->orderBy('sort_order', 'ASC')->get();
       $shippingMethods=ShippingMethods::where('status',1)->orderBy('sort_order', 'ASC')->get();

       $lastordUpdate= OrderUpdates::where('order_id',$order_details->order_id)->orderBy('created_at', 'desc')->first();
       $order_updates= OrderUpdates::with('shipmentStatus')->where('order_id',$order_details->order_id)->get();

       $order_updates = $order_updates->map(function($data)   {
            $data->status_name = OrderStatus::find($data->order_status_id)->order_status;    
            $data->attachment_url =url('/order_attachments/'.$data->attachment);
            $data->file_extension=pathinfo($data->attachment, PATHINFO_EXTENSION);

            if(!empty($data->shipmentStatus))
            $data->shipmentStatus->shipment_name=ShippingMethods::find($data->shipmentStatus->shipment_carrier)->method_name;
            
            return $data;
        });

       if(!empty($lastordUpdate))
       $lastordUpdateId=$lastordUpdate->order_status_id;
       else
       $lastordUpdateId=0;

       $res = [
            'order_details'=>$order_details,
            'order_status'=>$order_status,
            'shippingMethods'=>$shippingMethods,
            'lastordUpdateId'=>$lastordUpdateId,
            'invoice_biller_add'=>ApiHelper::getKeySetVal('invoice_biller_address'),
            'invoice_note'=>ApiHelper::getKeySetVal('invoice_note'),
            'order_updates'=>$order_updates,
        ];
     return ApiHelper::JSON_RESPONSE(true,$res,''); 
 }


 public function changeStatus(Request $request)
 {

    $api_token = $request->api_token;
    $order_update_data=$request->except(['api_token','order_id']);
    $data = Order::where('order_id', $request->order_id)->update($order_update_data);
    if($data)
        return ApiHelper::JSON_RESPONSE(true,$data,'SUCCESS_STATUS_UPDATE');
    else
        return ApiHelper::JSON_RESPONSE(false,[],'ERROR_STATUS_UPDATE');

}


    public function orderdetailspdf(Request $request){
        $api_token = $request->api_token;

           $order_details=Order::with('item','address','user','item.product.productdescription')->where('order_number',$request->order_number)->first();

           $currencyList = ApiHelper::Currancy();

           $logo_id= ApiHelper::getKeyVal('website_logo');

          $companydetails = [
            'contact_company_name' => ApiHelper::getKeyVal('contact_company_name'),
            'contact_email' => ApiHelper::getKeyVal('contact_email'),
            'contact_phone' => ApiHelper::getKeyVal('contact_phone'),
            'contact_address' => ApiHelper::getKeyVal('contact_address'),
            'contact_city' => ApiHelper::getKeyVal('contact_city'),
            'contact_state' => ApiHelper::getKeyVal('contact_state'), 
            'website_url' => ApiHelper::getKeyVal('website_url'), 
            'termCondition' => ApiHelper::getKeySetVal('invoice_term_and_condition'), 
            'website_logo' => ApiHelper::getFullImageUrl($logo_id),
            'bankdetails' => ''

          ];  

           


           $res = [
            'order_details'=>$order_details,
            'currencyList' => $currencyList,
            'companydetails' => $companydetails
        ];
           
         return ApiHelper::JSON_RESPONSE(true,$res,''); 
    }


    // Filter of products

    // public function OrderFilter(Request $request)
    // {
    //     $perPageItem = (int)$request->perPageItem ?? ApiHelper::perPageItem();
    //     $orderQuery =  Order::with('item','address');


    //      /* Add Start Date Filter  */
    //         if ($request->has('start_date')) {
    //             if($request->start_date !=NULL){
    //             $orderQuery = $orderQuery->whereDate('created_at', '<=', $request->start_date);
    //          }
    //         }

    //         /* Add End Date Filter  */
    //         if ($request->has('end_date')) {
    //             if($request->end_date !=NULL){
    //               $orderQuery = $orderQuery->whereDate('created_at', '>=', $request->end_date);
    //             }
    //         }

    //     /* Search Filter */

    //     if ($request->has('search')) {
    //         if($request->search !=NULL){
    //             $search=$request->search;

    //             $data_query=$orderQuery->where("order_number","LIKE", "%{$search}%")
    //             ->orWhereHas('item',function ($orderQuery)use($search)
    //             {
    //                 $orderQuery->where("product_name","LIKE", "%{$search}%");
    //             })
    //              ->orWhereHas('address',function ($orderQuery)use($search)
    //             {
    //                 $orderQuery->where("customer_name","LIKE", "%{$search}%")
    //                 ->orWhere('customer_email','Like','%'.$search.'%')->orWhere('customer_phone','Like','%'.$search.'%');
    //             });
    //       }
    //     }

    //     $order = $orderQuery->paginate($perPageItem);

    
    //     $res = [
    //         'order_list'=>$order,
    //     ];
           
    //     return ApiHelper::JSON_RESPONSE(true,$res,''); 

    // }
    
    public function UpdateOrderStatus(Request $request)
    {   
        $order_status_id= $request->order_status_id;
        $ordernotes= $request->ordernotes;
        $order_id= $request->order_id;
        $shipment_carrier=$request->shipment_carrier;
        $shipment_no=$request->shipment_no;
        $attachment=$request->file('attachment');

        $api_token = $request->api_token;

        $orderShipments='';
        $orderUpdates='';
        $fileName='';
        $extension='';

        $orderStatus=OrderStatus::where('id',$order_status_id)->first();

        if(!empty($orderStatus))
        {   
            if (!empty($attachment)) {
                
                $extension=$attachment->extension();
                $fileN=time();
                $fileName = $fileN.'.'.$extension;
                $path = $attachment->move(public_path('/order_attachments'), $fileName);
                
            };

          Order::where('order_id',$order_id)->update(['order_status'=>$order_status_id]);

           $orderUpdates= OrderUpdates::create([
                'order_id'=>$order_id,
                'order_status_id'=>$order_status_id,
                'update_note'=>$ordernotes,
                'attachment'=>$fileName
            ]); 

     
            if($orderStatus->shipment==1)
            {
               $orderShipments= OrderShipments::create([
                    'order_id'=>$order_id,
                    'order_update_id'=>$orderUpdates->id,
                    'shipment_carrier'=>$shipment_carrier, 
                    'shipment_no'=>$shipment_no, 
                ]);
            }

            $order_updates= OrderUpdates::with('shipmentStatus')->where('id',$orderUpdates->id)->first();
            $order_updates->status_name = OrderStatus::find($order_updates->order_status_id)->order_status;    
            
            if(!empty($order_updates->shipmentStatus))
            $order_updates->shipmentStatus->shipment_name=ShippingMethods::find($order_updates->shipmentStatus->shipment_carrier)->method_name;
            

        }
    

        $res = [
            'orderUpdates'=>$order_updates,
            'orderShipments'=>$orderShipments,
            'attachment_url'=>url('/order_attachments/'.$fileName),
            'date'=>date('d M , y', strtotime($order_updates->created_at ?? '')),
            'time'=>date('h:i', strtotime($order_updates->created_at ?? '')),
            'extension'=>$extension,
        ];

        return ApiHelper::JSON_RESPONSE(true,$res,''); 
    }


}
