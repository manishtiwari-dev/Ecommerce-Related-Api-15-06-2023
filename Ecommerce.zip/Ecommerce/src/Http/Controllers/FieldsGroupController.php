<?php
namespace Modules\Ecommerce\Http\Controllers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Modules\Ecommerce\Models\CategoryDescription;
use Modules\Ecommerce\Models\Category;
use Modules\Ecommerce\Models\FieldsGroup;

use App\Models\Language;
use ApiHelper;

use Illuminate\Support\Facades\Storage;

use Modules\Ecommerce\Models\Fields;


class FieldsGroupController extends Controller
{

    public $page = 'fieldsgroup';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        


        $current_page = !empty($request->page)?$request->page:1;
        $perPage = !empty($request->perPage)?(int)$request->perPage: ApiHelper::perPageItem();

        $search = $request->search;
        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;
        $language = $request->language;
        
        $data_query = FieldsGroup::select('fieldsgroup_id as value','fieldsgroup_name as label');
        
        if(!empty($search))
            // $data_query = $data_query->where("name","LIKE", "%{$search}%")->orWhere("email", "LIKE", "%{$search}%");

            /* order by sorting */
        if(!empty($sortBY) && !empty($ASCTYPE)){
            $data_query = $data_query->orderBy($sortBY,$ASCTYPE);
        }else{
            $data_query = $data_query->orderBy('fieldsgroup_id','ASC');
        }

        $skip = ($current_page == 1)?0:(int)($current_page-1)*$perPage;
        
        $user_count = $data_query->count();

        $data_list = $data_query->get();
        
     
        return ApiHelper::JSON_RESPONSE(true,$data_list,'');
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        


        //validation check 
        $rules = [
            'fieldsgroup_name' => 'required|string',
            'sort_order' => 'required',
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());
        }



        // store Fields 
        $saveData = $request->only(['sort_order','fieldsgroup_name','fieldsgroup_description']);
        // $saveData['parent_id'] = ($request->category_type == 'parent') ? $request->main_category : $request->sub_category;
        
        

        $cat = FieldsGroup::create($saveData);

       



        if($cat){
            return ApiHelper::JSON_RESPONSE(true,$cat,'SUCCESS_FIELDS_GROUP_ADD');
        }else{
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_FIELDS_GROUP_ADD');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {
        $response = FieldsGroup::find($request->fieldsgroup_id);
        return ApiHelper::JSON_RESPONSE(true,$response,'');

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $fieldsgroup_id = $request->fieldsgroup_id;

        // if(!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
        //     return ApiHelper::JSON_RESPONSE(false,[],'PAGE_ACCESS_DENIED');
        


        //validation check 
        $rules = [
            'fieldsgroup_id' => 'required',
            'sort_order' => 'required',
            'fieldsgroup_name' => 'required',
            'fieldsgroup_description' => 'required',
            
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) 
            return ApiHelper::JSON_RESPONSE(false,[],$validator->messages());
        

        // store fieldsgroup
        $saveData = $request->only(['sort_order','fieldsgroup_name','status','fieldsgroup_description']); 
        $fldg = FieldsGroup::where('fieldsgroup_id', $fieldsgroup_id)->update($saveData);

       
        if($fldg){
            return ApiHelper::JSON_RESPONSE(true,$saveData,'SUCCESS_FIELDS_GROUP_UPDATE');
        }else{
            return ApiHelper::JSON_RESPONSE(false,[],'ERROR_FIELDS_GROUP_UPDATE');
        }
    }


    public function changeStatus(Request $request){
        $api_token = $request->api_token;
        $infoData = FieldsGroup::find($request->fieldsgroup_id);
        $infoData->status = ($infoData->status == 0) ? 1 : 0;
        $infoData->save();
        return ApiHelper::JSON_RESPONSE(true,$infoData,'SUCCESS_STATUS_UPDATE');

    }
}
